package com.app.myhabittracker;

public class Habit {
    private String habitName;
    private String afterHabitDetail;
    private String habitNameDetail;

    public Habit() {
        // Default constructor required for Firebase
    }

    public Habit(String habitName, String afterHabitDetail, String habitNameDetail) {
        this.habitName = habitName;
        this.afterHabitDetail = afterHabitDetail;
        this.habitNameDetail = habitNameDetail;
    }

    // Getters and setters
    public String getHabitName() {
        return habitName;
    }

    public void setHabitName(String habitName) {
        this.habitName = habitName;
    }

    public String getAfterHabitDetail() {
        return afterHabitDetail;
    }

    public void setAfterHabitDetail(String afterHabitDetail) {
        this.afterHabitDetail = afterHabitDetail;
    }

    public String getHabitNameDetail() {
        return habitNameDetail;
    }

    public void setHabitNameDetail(String habitNameDetail) {
        this.habitNameDetail = habitNameDetail;
    }
}

