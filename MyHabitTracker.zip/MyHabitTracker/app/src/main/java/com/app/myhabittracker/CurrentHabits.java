package com.app.myhabittracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CurrentHabits extends AppCompatActivity {

    private TextView allHabitsText; // "All Habits" button to navigate to All Habit

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.current_habits); // Set the layout for this activity

        // Initialize the "All Habits" button (TextView)
        allHabitsText = findViewById(R.id.allHabitsText);

        // Set OnClickListener for the "All Habits" button
        allHabitsText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the All Habit screen
                Intent intent = new Intent(CurrentHabits.this, AllHabit.class);
                startActivity(intent);
            }
        });
    }
}

