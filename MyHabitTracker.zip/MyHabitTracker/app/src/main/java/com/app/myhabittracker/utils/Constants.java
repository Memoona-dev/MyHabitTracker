package com.app.myhabittracker.utils;

public class Constants {

    // Firestore collections
    public static final String usersCollection = "users"; // Update this with your actual Firestore collection name

}
