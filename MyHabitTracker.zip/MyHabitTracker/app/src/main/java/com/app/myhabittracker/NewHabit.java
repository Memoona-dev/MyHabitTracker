package com.app.myhabittracker;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class NewHabit extends AppCompatActivity {

    private EditText habitNameEditText, afterHabitEditText, habitNameDetailEditText;
    private Button createNewHabitButton;
    private ImageButton backbutton;
    private DatabaseReference databaseReference;

    // Declare the day TextViews
    private TextView monday, tuesday, wednesday, thursday, friday, saturday, sunday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_habit);

        // Initialize Firebase database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("Habits");

        // Initialize views
        habitNameEditText = findViewById(R.id.habitName);
        afterHabitEditText = findViewById(R.id.afterhabitEditText);
        habitNameDetailEditText = findViewById(R.id.habitNameEditText);
        createNewHabitButton = findViewById(R.id.createNewHabitButton);
        backbutton = findViewById(R.id.back_btn);

        // Initialize the day TextViews
        monday = findViewById(R.id.monday);
        tuesday = findViewById(R.id.tuesday);
        wednesday = findViewById(R.id.wednesday);
        thursday = findViewById(R.id.thursday);
        friday = findViewById(R.id.friday);
        saturday = findViewById(R.id.saturday);
        sunday = findViewById(R.id.sunday);

        // Set click listeners for each day
        setDayClickListener(monday);
        setDayClickListener(tuesday);
        setDayClickListener(wednesday);
        setDayClickListener(thursday);
        setDayClickListener(friday);
        setDayClickListener(saturday);
        setDayClickListener(sunday);

        // Set onClick listener for the back button
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Close the current activity
            }
        });

        // Set onClick listener for the create habit button
        createNewHabitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createNewHabit();
            }
        });
    }

    private void createNewHabit() {
        String habitName = habitNameEditText.getText().toString().trim();
        String afterHabitDetail = afterHabitEditText.getText().toString().trim();
        String habitNameDetail = habitNameDetailEditText.getText().toString().trim();

        if (habitName.isEmpty() || afterHabitDetail.isEmpty() || habitNameDetail.isEmpty()) {
            Toast.makeText(NewHabit.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Habit habit = new Habit(habitName, afterHabitDetail, habitNameDetail);
        String habitId = databaseReference.push().getKey();

        if (habitId != null) {
            databaseReference.child(habitId).setValue(habit)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d("NewHabit", "Habit created successfully!");
                            Toast.makeText(NewHabit.this, "Habit created successfully!", Toast.LENGTH_SHORT).show();

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    Intent intent = new Intent(NewHabit.this, AllHabit.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }, 500);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("NewHabit", "Failed to create habit: " + e.getMessage());
                            Toast.makeText(NewHabit.this, "Failed to create habit: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            Toast.makeText(NewHabit.this, "Error creating habit, please try again.", Toast.LENGTH_SHORT).show();
        }
    }



    // Set click listener for each day TextView
    private void setDayClickListener(final TextView dayTextView) {
        dayTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isSelected = dayTextView.isSelected();
                // Toggle the selected state
                dayTextView.setSelected(!isSelected);
            }
        });
    }
}

